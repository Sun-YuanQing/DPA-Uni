//index.js
//获取应用实例
let Paho = require("../../libs/paho-mqtt/paho-mqtt.js")

// console.log(Paho)
// client = new Paho.Client("192.168.0.198", 1883, "clientId")

var app = getApp()
Page({
  data: {
    motto: 'Hello World',
    userInfo: {}
  },
 
  onLoad: function () {
    
  },
  connetMQTTServer:function(){
    var client = new Paho.Client('192.168.0.3', 9011 ,"FIuserid");
    client.connect({
      keepAliveInterval: 60,
      cleanSession:true,
      useSSL:false,
      onSuccess: function () {
        console.log('connected');

        that.globalData.client = client

        client.onMessageArrived = function (msg) {
          if (typeof that.globalData.onMessageArrived === 'function') {
            return that.globalData.onMessageArrived(msg)
          }

          wx.showModal({
            title: msg.destinationName,
            content: msg.payloadString
          })
        }

        client.onConnectionLost = function (responseObject) {
          if (typeof that.globalData.onConnectionLost === 'function') {
            return that.globalData.onConnectionLost(responseObject)
          }
          if (responseObject.errorCode !== 0) {
            console.log("onConnectionLost:" + responseObject.errorMessage);
          }
        }
      },
      onFailure: function(err){
        console.log(err)
      }
    });
  }
})
