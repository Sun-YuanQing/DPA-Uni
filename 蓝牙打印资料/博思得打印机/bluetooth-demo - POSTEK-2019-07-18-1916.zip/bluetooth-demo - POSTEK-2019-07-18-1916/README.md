# 项目介绍
基于DCloud html5+的native.js, 实现的android蓝牙操作demo。

